<?php

namespace App\Http\Controllers;
namespace App\Providers;

use DB;
use View;
use Auth;
use User;
use App\Http\Requests;
use Illuminate\Http\Request;
use Illuminate\Support\ServiceProvider;

class AppServiceProvider extends ServiceProvider
{
    /**
     * Bootstrap any application services.
     *
     * @return void
     */

    public function boot()
    {
        // function deteleCouserExp()
        // {
        //   $dCouser = $id_user = DB::table('cousers')->get();
        //   foreach ($dCouser as $key => $value) {
        //     $daym =  $value -> created_at;
        //     $sepparator = '-';
        //     $partsExp = explode($sepparator, $daym);
        //     $d=cal_days_in_month(CAL_GREGORIAN,$partsExp[1],$partsExp[0]);
        //     $date_exp= ($d + 1) - (strtotime(date('Y-m-d')) - strtotime($value -> created_at)) / (60 * 60 * 24);
        //     if($date_exp == 0 && $value->action == 0){
        //        return $value->id;
        //     }
        //   }
        // }
        // $idCouser = deteleCouserExp();
        // DB::table('cousers')->where('id', $idCouser)->delete();
        // DB::table('registercousers')->where('id_couser', $idCouser)->delete();

        function getMeta() {
          
          echo '<meta property="og:url"     content="<?php ?>" />';
          echo '<meta property="og:type"          content="website" />';
          echo '<meta property="og:title"         content="Your Website Title" />';
          echo '<meta property="og:description"   content="Your description" />';
          echo '<meta property="og:image"         content="http://localhost:8081/hia/public/img/logo.png" />';
        }
        $text= DB::table('texts')->get();
        $sleft= DB::table('blogposts')->join('users','users.id','=','blogposts.by')->select('blogposts.*','users.name','users.avatar','users.level_user')->orderBy('viewed','desc')->get();
        $sright= DB::table('users')->get();
        $category= DB::table('categoryblogs')->get();
        view()->share(['text'=>$text,'sleft' => $sleft,'sright'=>$sright,'category'=> $category]);
    }

    /**
     * Register any application services.
     *
     * @return void
     */
    public function register()
    {
        //
    }
}
