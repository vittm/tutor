<?php

namespace App;

use Illuminate\Foundation\Auth\User as Authenticatable;

class Experiences extends Authenticatable
{

}
