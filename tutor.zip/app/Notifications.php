<?php

namespace App;

use Illuminate\Foundation\Auth\User as Authenticatable;

class Notifications extends Authenticatable
{

}
