@section('facebook_meta')
    <meta property="og:url" content="Place your data here">
    <meta property="og:image" content="Place your data here">
    <meta property="og:description" content="Place your data here">
@endsection
