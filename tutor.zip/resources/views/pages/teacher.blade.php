@extends('layouts.web')

@section('content')

<div class="col-md-12 pd0 cover-search">
	<img src="{{ url('img/cover1.png') }}" style="display:block;width:100%;margin: auto; height: 100%;">
	<h3 class="cover-search__title">HƯỚNG DẪN CHO GIÁO VIÊN</h3>
</div>

@endsection
